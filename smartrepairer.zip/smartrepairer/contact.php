<?php
echo "phone number:03477111268
      email:rehmat.ali@ucp.edu.pk";

?>